# base64

base64 encoding/decoding in solidity.

Also available as a package. Add it to `package.json`:

```
"base64-sol": "1.1.0"
```

and import it in solidity: 

```
import 'base64-sol/base64.sol';
```
